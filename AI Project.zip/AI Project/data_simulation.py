# data_simulation.py
import numpy as np
import pandas as pd
from math import sin, pi
import random

def simulate_walk_segment(duration_seconds=60, sampling_hz=50, step_frequency_hz=1.8, noise_level=0.05, steps=None):
    """
    Simulate accelerometer readings for walking/running segment.
    - duration_seconds: length in seconds
    - sampling_hz: samples per second
    - step_frequency_hz: how many steps per second (1.8 ~ 108 steps/min)
    """
    t = np.arange(0, duration_seconds, 1/sampling_hz)
    # base periodic acceleration magnitude from steps
    accel_base = 0.8 * np.abs(np.sin(2*pi*step_frequency_hz*t))  # half-wave to mimic step peaks
    # add small baseline and random noise
    noise = np.random.normal(scale=noise_level, size=t.shape)
    # create 3-axis by adding offsets and phase shifts
    ax = accel_base + noise + 0.02*np.sin(2*pi*0.2*t)
    ay = 0.8*0.5*accel_base + np.random.normal(scale=noise_level, size=t.shape)
    az = 0.6*accel_base + np.random.normal(scale=noise_level, size=t.shape)

    # optional jitter for different intensities
    return t, ax, ay, az

def simulate_dataset(minutes=30, sampling_hz=50):
    rows = []
    summary = []
    for minute in range(minutes):
        # choose activity intensity for each minute: 0=idle,1=walk,2=run
        act_choice = random.choices([0,1,2], weights=[0.25,0.6,0.15])[0]
        if act_choice == 0:
            # idle segment: very low movement
            t, ax, ay, az = simulate_walk_segment(duration_seconds=60, sampling_hz=sampling_hz, step_frequency_hz=0.1, noise_level=0.01)
            activity = 'idle'
            step_freq = 0.0
        elif act_choice == 1:
            # walk
            step_freq = random.uniform(1.2, 1.9)  # steps/sec
            t, ax, ay, az = simulate_walk_segment(duration_seconds=60, sampling_hz=sampling_hz, step_frequency_hz=step_freq, noise_level=0.05)
            activity = 'walking'
        else:
            # run/jog
            step_freq = random.uniform(2.0, 3.0)
            t, ax, ay, az = simulate_walk_segment(duration_seconds=60, sampling_hz=sampling_hz, step_frequency_hz=step_freq, noise_level=0.08)
            activity = 'running'

        # person weight in kg (choose from a small set)
        weight = random.choice([55, 60, 65, 70, 75, 80])

        # per-minute ground truth step count approx = step_freq * 60
        steps_gt = int(round(step_freq * 60)) if step_freq>0 else 0

        # write per-sample rows with absolute timestamps (minute offset)
        sample_times = (minute*60) + t  # second timestamps
        for i in range(len(sample_times)):
            mag = np.sqrt(ax[i]**2 + ay[i]**2 + az[i]**2)
            rows.append({
                'time_s': sample_times[i],
                'accel_x': ax[i],
                'accel_y': ay[i],
                'accel_z': az[i],
                'accel_mag': mag,
                'activity': activity,
                'weight_kg': weight,
                'minute': minute,
            })
        summary.append({'minute': minute, 'activity':activity, 'steps_gt':steps_gt, 'weight_kg':weight})

    df = pd.DataFrame(rows)
    summary_df = pd.DataFrame(summary)
    return df, summary_df

if __name__ == "__main__":
    df, summary_df = simulate_dataset(minutes=30, sampling_hz=50)
    df.to_csv("sim_data.csv", index=False)
    summary_df.to_csv("sim_summary.csv", index=False)
    print("Saved sim_data.csv (samples) and sim_summary.csv (per-minute summary).")
